// sami - واجهة المختبرات المعتمدة
export { default } from '../screensCommon/LabsScreen';
