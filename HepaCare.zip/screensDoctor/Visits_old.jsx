// backup of original Visits screen before search integration
